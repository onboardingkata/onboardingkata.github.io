from zeep import Client

client = Client("http://192.168.7.105:82/HttpFormiikBackEnd_Single.wsdl")

service = client.create_service(
    '{http://tempuri.org/}BasicHttpBinding_IBackEnd',
    'http://services.formiik.com:8081/BackEnd.svc')

remoteTime = service.CloudTime()

print(remoteTime)
