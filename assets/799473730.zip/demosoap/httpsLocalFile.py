import urllib, os
from zeep import Client


url = urllib.parse.urljoin('file:', urllib.request.pathname2url(os.path.abspath("/Users/McGregor/PycharmProjects/demosoap/wsdl_files/FormiikBackEnd_Single.wsdl")))

client = Client(url)

service = client.create_service(
    '{http://tempuri.org/}BasicHttpBinding_IBackEnd1',
    'https://services.formiik.com:8084/BackEnd.svc')


remoteTime = service.CloudTime()

# remoteTime = service.CloudTime()

print(remoteTime)
